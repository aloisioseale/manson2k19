# DelineatedTheme
A simple HTML5 portfolio theme for artists.
